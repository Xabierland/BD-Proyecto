﻿'------------------------------------------------------------------------------
' <generado automáticamente>
'     Este código fue generado por una herramienta.
'
'     Los cambios en este archivo podrían causar un comportamiento incorrecto y se perderán si
'     se vuelve a generar el código. 
' </generado automáticamente>
'------------------------------------------------------------------------------

Option Strict On
Option Explicit On


Partial Public Class FormularioFuncionesADM

    '''<summary>
    '''Control NombreLogin.
    '''</summary>
    '''<remarks>
    '''Campo generado automáticamente.
    '''Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    '''</remarks>
    Protected WithEvents NombreLogin As Global.System.Web.UI.WebControls.TextBox

    '''<summary>
    '''Control cambiarEstadoSocio.
    '''</summary>
    '''<remarks>
    '''Campo generado automáticamente.
    '''Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    '''</remarks>
    Protected WithEvents cambiarEstadoSocio As Global.System.Web.UI.WebControls.Button

    '''<summary>
    '''Control mostrarDatosSocio.
    '''</summary>
    '''<remarks>
    '''Campo generado automáticamente.
    '''Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    '''</remarks>
    Protected WithEvents mostrarDatosSocio As Global.System.Web.UI.WebControls.Button

    '''<summary>
    '''Control codPeliculaAlta.
    '''</summary>
    '''<remarks>
    '''Campo generado automáticamente.
    '''Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    '''</remarks>
    Protected WithEvents codPeliculaAlta As Global.System.Web.UI.WebControls.TextBox

    '''<summary>
    '''Control DarDeAltaPeli.
    '''</summary>
    '''<remarks>
    '''Campo generado automáticamente.
    '''Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    '''</remarks>
    Protected WithEvents DarDeAltaPeli As Global.System.Web.UI.WebControls.Button

    '''<summary>
    '''Control codPeliculaBaja.
    '''</summary>
    '''<remarks>
    '''Campo generado automáticamente.
    '''Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    '''</remarks>
    Protected WithEvents codPeliculaBaja As Global.System.Web.UI.WebControls.TextBox

    '''<summary>
    '''Control DarDeBajaPeli.
    '''</summary>
    '''<remarks>
    '''Campo generado automáticamente.
    '''Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    '''</remarks>
    Protected WithEvents DarDeBajaPeli As Global.System.Web.UI.WebControls.Button

    '''<summary>
    '''Control mostrarDatosPeli.
    '''</summary>
    '''<remarks>
    '''Campo generado automáticamente.
    '''Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    '''</remarks>
    Protected WithEvents mostrarDatosPeli As Global.System.Web.UI.WebControls.Button

    '''<summary>
    '''Control VolverPrincipal.
    '''</summary>
    '''<remarks>
    '''Campo generado automáticamente.
    '''Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    '''</remarks>
    Protected WithEvents VolverPrincipal As Global.System.Web.UI.WebControls.Button
End Class
